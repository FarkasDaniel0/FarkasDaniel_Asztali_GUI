package hu.petrik.calculator;

import javafx.beans.property.DoubleProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;

public class HelloController {

    @FXML
    private GridPane Grid;
    @FXML
    private Label outcome;
    @FXML
    private Spinner szam2;
    @FXML
    private Spinner szam1;
    @FXML
    private Button maradekososztasGomb;
    @FXML
    private Button szorozgomb;
    @FXML
    private Button kivongomb;
    @FXML
    private Button osszeadgomb;
    @FXML
    private Button osztasgomb;

    public void initialize() {
        szam1.setValueFactory(new SpinnerValueFactory.DoubleSpinnerValueFactory(-1000, 1000, 0));
        szam2.setValueFactory(new SpinnerValueFactory.DoubleSpinnerValueFactory(-1000, 1000, 0));
        szam1.getEditor().textProperty().addListener((observable, oldValue, newValue) -> {
            try {
                Double.parseDouble(newValue);
            } catch (NumberFormatException e) {
                szam1.getEditor().setText(oldValue);
            }
        });
        szam2.getEditor().textProperty().addListener((observable, oldValue, newValue) -> {
            try {
                Double.parseDouble(newValue);
            } catch (NumberFormatException e) {
                szam2.getEditor().setText(oldValue);
            }
        });

    }


        @FXML
    public void plusClick(ActionEvent actionEvent) {
        double first = (double) szam2.getValue();
        double second = (double) szam2.getValue();
        double result = first + second;
        outcome.setText(String.valueOf(result));
    }

    @FXML
    public void percentageClick(ActionEvent actionEvent) {
        double first = (double) szam1.getValue();
        double second = (double) szam2.getValue();
        double result = (first / second) * 100;
        outcome.setText(String.valueOf(result));

    }

    @FXML
    public void minusClick(ActionEvent actionEvent) {
        double first = (double) szam1.getValue();
        double second = (double) szam2.getValue();
        double result = first - second;
        outcome.setText(String.valueOf(result));
    }

    @FXML
    public void divisonClick(ActionEvent actionEvent) {
        double first = (double) szam1.getValue();
        double second = (double) szam2.getValue();
        double result = Math.round((first / second*100))/100.0;
        outcome.setText(String.valueOf(result));
    }


    @FXML
    public void multiplyClick(ActionEvent actionEvent) {
        double first = (double) szam1.getValue();
        double second = (double) szam2.getValue();
        double result = first * second;
        outcome.setText(String.valueOf(result));
    }
}