module hu.petrik.calculator {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens hu.petrik.calculator to javafx.fxml;
    exports hu.petrik.calculator;
}